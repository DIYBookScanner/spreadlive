/* dummy header for backward compatibility */
#include "iupcontrols.h"
#pragma message("Warning: Including an DEPRECATED header \"iupmatrix.h\". It will be removed in a future version. Use \"iupcontrols.h\".") 
